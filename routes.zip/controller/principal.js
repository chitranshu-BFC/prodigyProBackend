const logger = require('../utils/logger')(__filename);
const Students = require('../model/Students');
const Teachers = require('../model/Teachers');
const Exam = require('../model/Exam');
const Parents = require('../model/Parents');
const Principal = require('../model/Principal');
const Organization = require('../model/Organization');
const Events = require('../model/Events');
const Subjects = require('../model/Subjects');
const Schedule = require('../model/Schedule');
const Attendance = require('../model/Attendance');
const FeeStructure = require('../model/FeeStructure');

const mongoose = require('mongoose');
const moment = require('moment');
const Config = require('../utils/config');
const response = require('../utils/response');
const { hashPassword, comparePassword } = require('../utils/password');
const { query } = require('express');
const { generateToken, validateToken } = require('../utils/token');
const { func } = require('joi');

module.exports = {
    async addPrincipal(req, res) {
        logger.debug('controller>principal>addPrincipal')
        try {
            if (req.body == null || req.body == undefined) {
                return response.error(res, 400, { msg: "Empty params" });
            }

            const { id, Name, Address, ContactDetails, Gender } = req.body

            // return console.log("req.body principal ", req.body)

            let addedPrincipal = await Principal.create({ Organization_ref: id, Name, Address, ContactDetails, Gender })

            if (addedPrincipal == null || addedPrincipal == undefined) {
                return response.error(res, 500, { msg: "fail to add principal" });
            }

            return res.status(200).send({ success: true, msg: "Principal added successfully", data: addedPrincipal })
        } catch (error) {
            return res.status(500).send({ success: false, msg: "some error occured", error })
        }
    },

    async findPrincipals(req, res) {
        logger.debug('controller>principal>findPrincipals')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3) {
                return res.status(400).send({ success: false, msg: "Empty or Invalid params" })
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let foundPrincipal = await Principal.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (foundPrincipal.length < 1) {
                return res.status(400).send({ success: false, msg: "Sorry could not find requested record" })
            }

            return res.status(200).send({ success: true, msg: "Principal found", data: foundPrincipal })
        } catch (error) {
            return res.status(500).send({ success: false, msg: "some error occured", error })
        }
    },

    async studentAdmission(req, res) {
        logger.debug('controller>principal>studentAdmission')
        try {

            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let { Name, Address, Standard, Gender, Section, ParentName, DateOfBirth, ContactDetails, UUID, Caste, Category, Documents } = req.body;
            let Createdparent = await Parents.create({ Name: ParentName, Address, ContactDetails });

            let School = await Organization.findOne({ UUID });

            let RollNumber = await Students.count({ Section: Section, Standard: Standard }) + 1;

            let SUID = UUID + 'S' + Standard + Section + RollNumber;

            //Creating and hashing password
            let Password = SUID + Math.floor((Math.random() * 10000) + 1)
            let HashedPassword = await hashPassword(Password);


            //adding document name
            Documents = Documents.map(doc => doc = `${Config.AWS.STUDENTS_BUCKET_URL}${doc.split(".").at(0)}_${ContactDetails[0]}_${SUID}.${doc.split(".").at(-1)}`)

            let addedStudent = await Students.create({
                Name, Address, Category, Caste, Standard, Gender, Section, ParentName, DateOfBirth, ContactDetails, RollNumber, Parent_ref: Createdparent._id, SUID,
                Organization_ref: School._id, Documents, HashedPassword
            })

            addedStudent._doc.PasswordString = Password;

            if (!addedStudent || addedStudent == null || addedStudent == undefined) {
                return response.error(500, 400, { msg: "some error occured, could not create record" });
            }

            return response.success(res, 200, addedStudent);
        } catch (error) {
            // console.log("error creating student ", error)
            return response.error(res, 500, error);
        }
    },

    async studentDetails(req, res) {
        logger.debug('controller>principal>studentDetails')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let foundStudent = await Students.find(restParams, { HashedPassword: 0 })
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (foundStudent.length < 1) {
                return response.error(500, 400, { msg: "Sorry could not find requested record" });
            }

            return response.success(res, 200, foundStudent);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async getDashboard(req, res) {
        logger.debug('controller>principal>getDashboard')
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;


            //students count
            let foundStudent = Students.count({})

            //teachers count
            let foundTeachers = Teachers.count({})

            //classes count
            let foundClasses = Subjects.find(restParams)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true })
                .lean();

            //Events
            let foundEvents = Events.find(restParams).skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true })
                .lean();

            //Exams
            let foundExams = Exam.find(restParams).skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true })
                .lean();


            let Promises = [foundStudent, foundTeachers, foundClasses, foundEvents, foundExams]

            Promise.allSettled(Promises).then((results) => {

                let keys = ['StudentCount', 'TeachersCount', 'Classes', 'Events', 'Exams']

                results.forEach((result, idx) => {
                    result[`${keys[idx]}`] = result['value'];
                    delete result['value'];
                })

                return response.success(res, 200, {
                    settledResults: results,
                });
            })
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async addTeachers(req, res) {
        logger.debug('controller>principal>addTeachers')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let { Name, Organization_ref, Address, Gender, ContactDetails, Subjects, ClassIncharge, Documents } = req.body

            //Creating and hashing password

            let Password = `${Name}-${Math.floor((Math.random() * 10000) + 1)}`;
            let HashedPassword = await hashPassword(Password);


            //Adding documents Name
            Documents = Documents.map(doc => doc = `${Config.AWS.TEACHERS_BUCKET_URL}${Organization_ref}_${ContactDetails[0]}.${doc.split(".").at(-1)}`)

            let addedTeacher = await Teachers.create({ Name, Organization_ref, Address, Gender, ContactDetails, Subjects, ClassIncharge, Documents, HashedPassword })

            if (addedTeacher == null || addedTeacher == undefined) {
                return response.error(res, 500, { msg: "Some error occured, failed to add teacher" })
            }

            addedTeacher._doc.PasswordString = Password;

            return response.success(res, 200, addedTeacher);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async teacherDetails(req, res) {
        logger.debug('controller>principal>teacherDetails')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = req.query.pageNumber ? parseInt(req.query.pageNumber) : 1;
            let nPerPages = req.query.pageNumber ? parseInt(req.query.nPerPage) : 1;

            const { pageNumber, nPerPage, Name, authorization, ...restParams } = req.query;

            let query = Name ? { Name: { $regex: `${Name}`, $options: 'i' }, restParams } : restParams;


            let foundTeacher = await Teachers.find(query, {HashedPassword: 0})
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .lean();


            if (foundTeacher.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find requested record" })
            }

            return response.success(res, 200, foundTeacher)
        } catch (error) {
            console.log(error)
            return response.error(res, 500, error);
        }
    },

    async getAllTeachers(req, res) {
        logger.debug('controller>principal>getAllTeachers')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = req.query.pageNumber ? parseInt(req.query.pageNumber) : 1;
            let nPerPages = req.query.nPerPage ? parseInt(req.query.nPerPage) : 50;

            const { pageNumber, nPerPage, authorization, ...restParams } = req.query;

            console.log("restParams ", restParams)

            let foundTeacher = await Teachers.find({Organization_ref: '6244213b20f3d77958b77e91'})            
            .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
            .limit(nPerPages ? nPerPages : 50)
            .lean();
            
            // console.log("foundTeacher ",foundTeacher )

            if (foundTeacher.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find requested record" })
            }

            return response.success(res, 200, foundTeacher)
        } catch (error) {
            console.log(error)
            return response.error(res, 500, error);
        }
    },


    async addFee(req, res) {
        logger.debug('controller>principal>addFee')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }


            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let addedFee = await FeeStructure.create(req.body)

            if (!addedFee || addedFee == null || addedFee == undefined) {
                return response.error(res, 500, { msg: "fail to create fee structure" });
            }

            return response.success(res, 200, addedFee)
        } catch (error) {
            // console.log("error from fee structure ", error);
            return response.error(res, 500, error);
        }
    },

    async getFee(req, res) {
        logger.debug('controller>principal>getFee')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = req.query.pageNumber ? parseInt(req.query.pageNumber) : 1;
            let nPerPages = req.query.pageNumber ? parseInt(req.query.nPerPage) : 1;

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let foundFeeStructure = await FeeStructure.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .lean();

            if (foundFeeStructure.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find requested record" })
            }
            return response.success(res, 200, foundFeeStructure)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async markAttendance(req, res) {
        logger.debug('controller>principal>markAttendance')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            //parsing string date to Date format
            req.body.Date = moment(req.body.Date)

            // creating record
            let attendance = await Attendance.create(req.body)

            if (!attendance || attendance == null || attendance == undefined) {
                return response.error(res, 500, { msg: "fail to mark attendance" });
            }

            return response.success(res, 200, attendance)
        } catch (error) {
            // console.log("error from attendance ", error);
            return response.error(res, 500, error);
        }
    },

    async getStudentAttendance(req, res) {
        logger.debug('controller>principal>getStudentAttendance')
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id);

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            //parsing params
            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            let { pageNumber, nPerPage, Start, End, ...restParams } = req.query;

            if (restParams.Standard) {
                restParams.Standard = parseInt(restParams.Standard)
            }

            //Getting results
            let attendance = await Attendance.find({
                $and: [
                    {
                        restParams
                    },
                    {
                        Date: { $gte: moment(Start), $lte: moment(End) }
                    }
                ]
            }).skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .populate({ path: 'AttendeeId', select: ['Name', 'RollNumber'] })
                .limit(nPerPages ? nPerPages : 50).lean();

            if (attendance.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not get attendance" })
            }

            return response.success(res, 200, attendance)
        } catch (error) {
            // console.log("error ",error)
            return response.error(res, 500, error);
        }
    },

    async getAttendance(req, res) {
        logger.debug('controller>principal>getAttendance')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.query.Organization_ref || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            //parsing params
            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, Start, End, ...restParams } = req.query;

            //Getting results
            let attendance = await Attendance.find({
                $and: [
                    {
                        restParams
                    },
                    {
                        Date: { $gte: moment(Start), $lte: moment(End) }
                    }
                ]
            }).skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (attendance.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not get data" })
            }

            return response.success(res, 200, attendance)
        } catch (error) {
            // console.log("error ", error)
            return response.error(res, 500, error);
        }
    },

    async scheduleExam(req, res) {
        logger.debug('controller>principal>scheduleExam')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let createdExam = await Exam.create(req.body);

            if (createdExam == null || createdExam == undefined) {
                return response.error(res, 500, { msg: "fail to schedule exam" });
            }

            return response.success(res, 200, createdExam);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },


    async filterExam(req, res) {
        logger.debug('controller>principal>filterExam')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let exams = await Exam.find(restParams).skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .populate({ path: 'Coordinator_refs', select: 'Name' })
                .setOptions({ sanitizeFilter: true })
                .lean();

            if (exams.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find exam data" })
            }

            return response.success(res, 200, exams)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async addSubjects(req, res) {
        logger.debug('controller>principal>addSubjects')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let AddededSubject = await Subjects.findOneAndUpdate({ Standard: req.body.Standard },
                { $push: { Subjects: req.body.Subjects, Sections: req.body.Sections } }, { new: true, upsert: true });

            if (AddededSubject == null || AddededSubject == undefined) {
                return response.error(res, 500, { msg: "failed to Add Subject" });
            }

            return response.success(res, 200, AddededSubject);
        } catch (error) {
            // console.log("error subjects ", error)
            return response.error(res, 500, error);
        }
    },


    async getSubjects(req, res) {
        logger.debug('controller>principal>getSubjects')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let foundSubjects = await Subjects.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).lean();

            if (foundSubjects.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find data" })
            }

            return response.success(res, 200, foundSubjects);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async parentRegister(req, res) {
        logger.debug('controller>principal>parentRegister')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" })
            }


            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let addedParents = Parents.create(req.body);

            if (addedParents == null || addedParents == undefined) {
                return response.error(res, 500, { msg: "fail to add parent" })
            }

            return response.success(res, 200, addedParents)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async addEvents(req, res) {
        logger.debug('controller>principal>addEvents')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/token" })
            }


            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }



            let addedEvents = await Events.create(req.body);

            if (addedEvents == null || addedEvents == undefined) {
                return response.error(res, 400, { msg: "fail to add Events" })
            }

            return response.success(res, 200, addedEvents)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async findEvents(req, res) {
        logger.debug('controller>principal>findEvents')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.query.length < 3 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let addedEvents = await Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true }).lean();

            if (addedEvents.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find data" })
            }

            return response.success(res, 200, addedEvents)
        } catch (error) {
            // console.log("error ",error)
            return response.error(res, 500, error);
        }
    },

    async addSchedule(req, res) {
        logger.debug('controller>principal>addSchedule')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let addedSchedule = await Schedule.findOneAndUpdate(req.body.Teacher_ref, req.body, { upsert: true, new: true }).lean()

            if (!addedSchedule || addedSchedule == undefined) {
                return response.error(res, 400, { msg: "Sorry could not Create Schedule" })
            }

            return response.success(res, 200, addedSchedule)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },


    async findSchedule(req, res) {
        logger.debug('controller>principal>findSchedule')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Principal.findById(verifiedToken._id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || !req.query.length > 3) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let foundSchedule = await Schedule.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true }).lean();

            if (foundSchedule.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find data" })
            }

            return response.success(res, 200, foundSchedule)
        } catch (error) {
            // console.log("error from schedule ", error)
            return response.error(res, 500, error);
        }
    },

    async login(req, res) {
        logger.debug('controller>principal>login');
        try {

            if (req.body == null || req.body == undefined || req.query.nPerPage > 50) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }

            const { userId, password } = req.body;

            let principal = await Principal.findOne({ ContactDetails: userId })
            .populate({ path: 'Organization_ref', select: ['Name'] });

            if (!principal || principal == undefined) {
                return response.error(res, 400, { msg: "User not found" });
            }

            let verified = await comparePassword(password, principal.HashedPassword);


            if (!verified) {
                return response.error(res, 400, { msg: "Invalid userId/password" });
            }

            const { HashedPassword, ...restDetails } = principal._doc;


            let token = await generateToken(restDetails);
            restDetails.token = token;

            return response.success(res, 200, restDetails);
        } catch (error) {
            // console.log(error)
            return response.error(res, 500, error);
        }
    },


}