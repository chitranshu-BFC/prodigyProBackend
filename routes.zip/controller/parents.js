const logger = require('../utils/logger')(__filename);
const response = require('../utils/response');

const Students = require('../model/Students');
const Issues = require('../model/Issue')

module.exports = {
    async allChilds(req, res) {
        logger.debug('controller>Parents>allChilds');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let child = await Students.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true }).lean();

            if (child.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find events" });
            }

            return response.success(res, 200, child);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async raiseIssue(req, res) {
        logger.debug('controller>Parents>raiseIssue');
        try {

            if (req.body == null || req.body == undefined) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }


            let issue = await Issues.create(req.body)

            if (issue == null || issue == undefined) {
                return response.error(res, 500, { msg: "fail to raise issue, please try again" });
            }

            return response.success(res, 200, issue);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async findRaisedIssue(req, res) {
        logger.debug('controller>Parents>findRaisesIssue');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let issues = await Issues.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0).limit(nPerPages ? nPerPages : 50)
                .setOptions({ sanitizeFilter: true }).lean();

            if (issues.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find issues" });
            }

            return response.success(res, 200, issues);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },
}