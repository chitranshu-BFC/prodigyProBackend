const logger = require('../utils/logger')(__filename);
const response = require('../utils/response');
const { comparePassword } = require('../utils/password');
const { generateToken, validateToken } = require('../utils/token');
const CONFIG = require('../utils/config');

const Exam = require('../model/Exam');
const Events = require('../model/Events');
const Student = require('../model/Students');
const Attendance = require('../model/Attendance');

module.exports = {
    async allExams(req, res) {
        logger.debug('controller>Students>allExams');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Student.findOne({ SUID: verifiedToken.SUID })

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let exams = await Exam.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50)
                .populate({ path: 'Coordinator_refs', select: 'Name' })
                .populate({ path: 'Teacher_refs', select: 'Name' })
                .setOptions({ sanitizeFilter: true })
                .lean();

            if (exams.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find exams" });
            }

            return response.success(res, 200, exams);
        } catch (error) {
            console.log("error from exams ", error)
            return response.error(res, 500, error);
        }
    },

    async allEvents(req, res) {
        logger.debug('controller>Students>allEvents');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Student.findOne({ SUID: verifiedToken.SUID })

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let events = await Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (events.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find events" });
            }

            return response.success(res, 200, events);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },


    async getAttendance(req, res) {
        logger.debug('controller>Students>getAttendance');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Student.findOne({ SUID: verifiedToken.SUID })

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let events = await Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (events.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find events" });
            }

            return response.success(res, 200, events);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async raiseIssue(req, res) {
        logger.debug('controller>Students>raiseIssue');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Student.findOne({ SUID: verifiedToken.SUID })

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let events = await Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (events.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find events" });
            }

            return response.success(res, 200, events);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async Dashboard(req, res) {
        logger.debug('controller>Students>Dashboard');
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" });
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Student.findOne({ SUID: verifiedToken.SUID })

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let holidays = Attendance.find({ Holiday: true })
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).lean();

            let events = Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).lean();

            let attendance = Attendance.find({ AttendeeId: verifiedUser._id })
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).lean();


            let Promises = [holidays, events, attendance]

            Promise.allSettled(Promises).then((results) => {

                let keys = ['Holidays', 'Events', 'Attendance']

                results.forEach((result, idx) => {
                    result[`${keys[idx]}`] = result['value'];
                    delete result['value'];
                })

                return response.success(res, 200, results);
            })

        } catch (error) {
            console.log("error ",error)
            return response.error(res, 500, error);
        }
    },

    async login(req, res) {
        logger.debug('controller>Students>login');
        try {

            if (req.body == null || req.body == undefined || req.query.nPerPage > 50) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }

            const { userId, password } = req.body;

            let student = await Student.findOne({ SUID: userId });

            if (!student || student == undefined) {
                return response.error(res, 400, { msg: "User not found" });
            }

            let verified = await comparePassword(password, student.HashedPassword);

            if (!verified) {
                return response.error(res, 400, { msg: "Invalid userId/password" });
            }

            let token = await generateToken({ SUID: student.SUID, RollNumber: student.RollNumber, Standard: student.Standard, Section: student.Section })


            let data = {
                Organization_ref: student.Organization_ref,
                _id: student._id,
                Name: student.Name,
                Address: student.Address,
                ContactDetails: student.ContactDetails,
                Subjects: student.Subjects,
                RollNumber: student.RollNumber,
                Role: student.Role,
                RegisteredAt: student.RegisteredAt,
                Parent_ref: student.Parent_ref,
                DateOfBirth: student.DateOfBirth,
                Standard: student.Standard,
                Section: student.Section,
                ParentName: student.ParentName,
                BloodGroup: student.BloodGroup,
                SUID: student.SUID,
                token
            }


            return response.success(res, 200, data);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },
}