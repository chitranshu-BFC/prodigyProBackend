const router = require('express').Router();
//routes
const CONFIG = require("../utils/config");
const {
    ADD_PRINCIPAL,
    FIND_PRINCIPAL,
    REGISTER_STUDENT,
    FIND_STUDENTS,
    ADD_TEACHER,
    FIND_TEACHER,
    SCHEDULE_EXAM,
    GET_EXAMS,
    REGISTER_PARENT,
    ADD_EVENTS,
    GET_EVENTS,
    MARK_ATTENDANCE,
    GET_ATTENDANCE,
    STUDENT_ATTENDANCE,
    ADD_SUBJECTS,
    GET_SUBJECTS,
    ADD_SCHEDULE,
    GET_SCHEDULE,
    GET_DASHBOARD,
    GET_ALL_TEACHERS,
    ADD_FEE,
    GET_FEE,
    LOGIN
} = CONFIG.ROUTES

//controllers
const {
    studentAdmission,
    studentDetails,
    addTeachers,
    teacherDetails,
    scheduleExam,
    filterExam,
    parentRegister,
    addPrincipal,
    findPrincipals,
    findEvents,
    addEvents,
    getAttendance,
    markAttendance,
    addSubjects,
    getSubjects,
    addSchedule,
    findSchedule,
    getDashboard,
    getStudentAttendance,
    addFee,
    getFee,
    login,
    getAllTeachers
} = require('../controller/principal');

//token verify middleware
const { verifyToken } = require('../middleware/token');

//Add Principal
router.post(ADD_PRINCIPAL, addPrincipal);

//Find Principal
router.get(FIND_PRINCIPAL, findPrincipals);

//Principal Login
router.post(LOGIN, login);

//Get Dashboard
router.get(GET_DASHBOARD, getDashboard);

//Get AllTeachers
router.get(GET_ALL_TEACHERS, getAllTeachers);

//Register Parent
router.post(REGISTER_PARENT, parentRegister);

//Register Student
router.post(REGISTER_STUDENT, studentAdmission);

//Find Students
router.get(FIND_STUDENTS, studentDetails);

//Student Attendance
router.get(STUDENT_ATTENDANCE, getStudentAttendance);

//Add teachers
router.post(ADD_TEACHER, addTeachers);

//Find Teachers
router.get(FIND_TEACHER, teacherDetails);

//Create Exam
router.post(SCHEDULE_EXAM, scheduleExam);

//Get all exam
router.get(GET_EXAMS, filterExam);

//Add Events
router.post(ADD_EVENTS, addEvents);

//Find Events
router.get(GET_EVENTS, findEvents);

//Mark Attendance
router.post(MARK_ATTENDANCE, markAttendance)

//Get Attendance
router.get(GET_ATTENDANCE, getAttendance)

//Add Subjects
router.post(ADD_SUBJECTS, addSubjects);

//Get Subjects
router.get(GET_SUBJECTS, getSubjects);

//Add Schdedule
router.post(ADD_SCHEDULE, addSchedule);

//Get Schedule
router.get(GET_SCHEDULE, findSchedule);

//Add Fee
router.post(ADD_FEE, addFee);

//Get Fee
router.get(GET_FEE, getFee);


module.exports = router;
