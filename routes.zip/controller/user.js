const logger = require('../utils/logger')(__filename);
const Config = require('../utils/config');
const response = require('../utils/response');
const { hashPassword, comparePassword } = require('../utils/password');

const User = require('../model/User');
const Principal = require('../model/Principal');

module.exports = {
    async userLogin(req, res) {
        logger.debug('controller>user>userLogin')
        try {
            if (req.body == null || req.body == undefined) {
                return res.status(400).send({ success: false, msg: "Empty params" })
            }

            const { userEmail, Password } = req.body;
                
            let verifiedUser = await User.findOne({ userEmail });
            
            if (!verifiedUser || verifiedUser.password != Password ) {
                return res.status(400).send({ success: false, msg: "Sorry invalid user" })
            }

            return res.status(200).send({ success: true, msg: "verified", data: verifiedUser.userEmail })
        } catch (error) {
            // console.log("error from addOrganization ", error)
            return res.status(500).send({ success: false, msg: "some error occured", error })
        }
    },

    async addPrincipal(req, res) {
        logger.debug('controller>user>addPrincipal')
        try {
            if (req.body == null || req.body == undefined) {
                return response.error(res, 400, { msg: "Empty params" });
            }

            let { Name, Organization_ref, Address, Gender, ContactDetails, Documents } = req.body

            //Creating and hashing password

            let Password = `${Name}-${Math.floor((Math.random() * 10000) + 1)}`;
            let HashedPassword = await hashPassword(Password);


            //Adding documents Name
            Documents = Documents.map(doc => doc = `${Config.AWS.PARENTS_BUCKET_URL}${doc.split(".").at(0)}_Principal_${Organization_ref}_${ContactDetails[0]}.${doc.split(".").at(-1)}`)

            let addedPrincipal = await Principal.create({ Name, Organization_ref, Address, Gender, ContactDetails, Documents, HashedPassword })

            if (addedPrincipal == null || addedPrincipal == undefined) {
                return response.error(res, 500, { msg: "Some error occured, failed to add teacher" })
            }

            addedPrincipal._doc.PasswordString = Password;

            return response.success(res, 200, addedPrincipal);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

}