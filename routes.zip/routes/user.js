const router = require('express').Router();
//routes
const CONFIG = require("../utils/config");
const{
    USER_LOGIN,
    ADD_PRINCIPAL
}=CONFIG.ROUTES

//controllers
const{
    userLogin,
    addPrincipal
}=require('../controller/user');


//User Login
router.post(USER_LOGIN, userLogin);

//Add Principal
router.post(ADD_PRINCIPAL, addPrincipal);


module.exports = router;