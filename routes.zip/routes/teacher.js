const router = require('express').Router();
//routes
const CONFIG = require("../utils/config");
const {
    ADD_EVENTS,
    GET_EVENTS,
    SCHEDULE_EXAM,
    GET_EXAMS,
    LOGIN,
    MARK_ATTENDANCE,
    GET_ATTENDANCE,
    FIND_STUDENTS,
    GET_SUBJECTS,
    GET_SCHEDULE,
    REQUEST_LEAVE
} = CONFIG.ROUTES

//controllers
const {
    addEvents,
    findEvents,
    scheduleExam,
    filterExam,
    login,
    getAttendance,
    markAttendance,
    findStudents,
    getSubjects,
    getSchedule,
    requestLeave
} = require('../controller/teachers');

//Get Students
router.get(FIND_STUDENTS, findStudents);

//Get Schedule
router.get(GET_SCHEDULE, getSchedule);

//Add Events
router.post(ADD_EVENTS, addEvents);

//Find Events
router.get(GET_EVENTS, findEvents);

//Create Exam
router.post(SCHEDULE_EXAM, scheduleExam);

//Get all exam
router.get(GET_EXAMS, filterExam);

//Mark Attendance
router.post(MARK_ATTENDANCE, markAttendance)

//Get Attendance
router.get(GET_ATTENDANCE, getAttendance)

//Get Subjects
router.get(GET_SUBJECTS, getSubjects)

//Request Leave
router.post(REQUEST_LEAVE, requestLeave)

//Login
router.post(LOGIN, login);



module.exports = router;
