const logger = require('../utils/logger')(__filename);
const response = require('../utils/response');
const { comparePassword } = require('../utils/password')
const { generateToken, validateToken } = require('../utils/token')
const moment = require('moment');
const mongoose = require('mongoose');

const Events = require('../model/Events');
const Teachers = require('../model/Teachers');
const Attendance = require('../model/Attendance');
const Exam = require('../model/Exam');
const Students = require('../model/Students');
const Subjects = require('../model/Subjects');
const Schedule = require('../model/Schedule');
const Leave = require('../model/Leave');

module.exports = {
    async addEvents(req, res) {
        logger.debug('controller>teachers>addEvents')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let addedEvents = await Events.create(req.body);

            if (addedEvents == null || addedEvents == undefined) {
                return response.error(res, 400, { msg: "fail to add Events" })
            }

            return response.success(res, 200, addedEvents)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async findEvents(req, res) {
        logger.debug('controller>teachers>addEvents')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let addedEvents = await Events.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (addedEvents.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find data" })
            }

            return response.success(res, 200, addedEvents)
        } catch (error) {
            // console.log("error ", error)
            return response.error(res, 500, error);
        }
    },

    async findStudents(req, res) {
        logger.debug('controller>teachers>findStudents')
        try {

            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;
            if(restParams.Standard){
                restParams.Standard = parseInt(restParams.Standard)
            }

            let addedEvents = await Students.find(restParams,{ HashedPassword: 0 })
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();


            if (addedEvents.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find data" })
            }

            return response.success(res, 200, addedEvents)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async scheduleExam(req, res) {
        logger.debug('controller>teachers>scheduleExam')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            let createdExam = await Exam.create(req.body);

            if (createdExam == null || createdExam == undefined) {
                return response.error(res, 500, { msg: "fail to schedule exam" });
            }

            return response.success(res, 200, createdExam);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async getSubjects(req, res) {
        logger.debug('controller>teachers>getSubjects')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let exams = await Subjects.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (exams.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find exam data" })
            }

            return response.success(res, 200, exams)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },


    async filterExam(req, res) {
        logger.debug('controller>teachers>filterExam')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            let exams = await Exam.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .populate({ path: 'Coordinator_refs', select: 'Name' })
                .limit(nPerPages ? nPerPages : 50).setOptions({ sanitizeFilter: true }).lean();

            if (exams.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find exam data" })
            }

            return response.success(res, 200, exams)
        } catch (error) {
            return response.error(res, 500, error);
        }
    },

    async getSchedule(req, res) {
        logger.debug('controller>teachers>getSchedule')
        try {
            if (req.query == null || req.query == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            let pageNumbers = parseInt(req.query.pageNumber);
            let nPerPages = parseInt(req.query.nPerPage);

            const { pageNumber, nPerPage, ...restParams } = req.query;

            // if(restParams.Teacher_ref){
            //     restParams.Teacher_ref = mongoose.Types.ObjectId(restParams.Organization_ref)
            // }

            // console.log("restParams ", {Teacher_ref:new mongoose.Types.ObjectId(restParams.Teacher_ref)})

            let exams = await Schedule.find(restParams)
                .skip(pageNumbers > 0 ? (pageNumbers - 1) * nPerPages : 0)
                .limit(nPerPages ? nPerPages : 50).lean();

                // console.log("exams ", exams)

            if (exams.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find Schedule" })
            }

            return response.success(res, 200, exams)
        } catch (error) {
            console.log("error ",error)
            return response.error(res, 500, error);
        }
    },

    async markAttendance(req, res) {
        logger.debug('controller>teachers>markAttendance')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }
        
            let verifiedToken = await validateToken(req.headers.authorization);
            
            if (!verifiedToken || verifiedToken == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined || verifiedToken == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }


            //parsing string date to Date format
            req.body.Date = moment(req.body.Date)

            // creating record
            let attendance = await Attendance.create(req.body)

            if (!attendance || attendance == null || attendance == undefined) {
                return response.error(res, 500, { msg: "fail to mark attendance" });
            }

            return response.success(res, 200, attendance)
        } catch (error) {
            // console.log("error from attendance ", error);
            return response.error(res, 500, error);
        }
    },

    async requestLeave(req, res) {
        logger.debug('controller>teachers>requestLeave')
        try {
            if (req.body == null || req.body == undefined || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            //parsing string date to Date format
            req.body.StartDate = moment(req.body.StartDate);
            req.body.EndDate = moment(req.body.EndDate);

            // creating record
            let Leave = await Leave.create(req.body);

            if (!Leave || Leave == null || Leave == undefined) {
                return response.error(res, 500, { msg: "fail to request leave" });
            }

            return response.success(res, 200, Leave)
        } catch (error) {
            // console.log("error from attendance ", error);
            return response.error(res, 500, error);
        }
    },

    async getAttendance(req, res) {
        logger.debug('controller>teachers>getAttendance')
        try {

            if (req.body == null || req.body == undefined || req.query.nPerPage > 50 || !req.headers.authorization) {
                return response.error(res, 400, { msg: "Empty or Invalid params/Token" })
            }

            let verifiedToken = await validateToken(req.headers.authorization);
            let verifiedUser = await Teachers.findById(verifiedToken.Id)

            if (!verifiedToken || !verifiedUser || verifiedUser == undefined) {
                return response.error(res, 400, { msg: "Sorry Invalid User/Token" });
            }

            //parsing params
            let pageNumber = parseInt(req.query.pageNumber);
            let nPerPage = parseInt(req.query.nPerPage);

            let { Start, End, ...rest } = req.query;

            //Getting results
            let attendance = await Attendance.find({
                $and: [
                    {
                        rest
                    },
                    {
                        Date: { $gte: moment(Start), $lte: moment(End) }
                    }
                ]
            }).skip(pageNumber > 0 ? (pageNumber - 1) * nPerPage : 0).limit(nPerPage ? nPerPage : 50).lean();

            if (attendance.length < 1) {
                return response.error(res, 400, { msg: "Sorry could not find exam data" })
            }

            return response.success(res, 200, attendance)
        } catch (error) {
            // console.log("error ", error)
            return response.error(res, 500, error);
        }
    },

    async login(req, res) {
        logger.debug('controller>teachers>login');
        try {

            if (req.body == null || req.body == undefined || req.query.nPerPage > 50) {
                return response.error(res, 400, { msg: "Empty or Invalid params" });
            }

            const { userId, password } = req.body;

            let teacher = await Teachers.findOne({ ContactDetails: userId });

            if (!teacher || teacher == undefined) {
                return response.error(res, 400, { msg: "User not found" });
            }

            let verified = await comparePassword(password, teacher.HashedPassword);

            if (!verified) {
                return response.error(res, 400, { msg: "Invalid userId/password" });
            }

            let token = await generateToken({ Id: teacher._id, ClassIncharge: teacher.ClassIncharge, Organization_ref: teacher.Organization_ref });
            let data = {
                Organization_ref: teacher.Organization_ref,
                _id: teacher._id,
                Name: teacher.Name,
                Address: teacher.Address,
                ContactDetails: teacher.ContactDetails,
                Subjects: teacher.Subjects,
                ClassIncharge: teacher.ClassIncharge,
                Role: teacher.Role,
                RegisteredAt: teacher.RegisteredAt,
                token
            }

            return response.success(res, 200, data);
        } catch (error) {
            return response.error(res, 500, error);
        }
    },
}