const router = require('express').Router();


//routes
const CONFIG = require("../utils/config");
const {
    SIPROUTE,
    ELSSROUTE,
    EMIROUTE
} = CONFIG.ROUTES

//controllers
const {
    SipCalculator,
    ELSSCalculator,
    EMICalculator
} = require('../controller/calculators');

//token verify middleware
const { verifyToken } = require('../middleware/token');

//SIP Route
router.post(SIPROUTE, SipCalculator);

//ELSS ROUTE
router.post(ELSSROUTE, ELSSCalculator);

//EMI ROUTE
router.post(EMIROUTE, EMICalculator);


module.exports = router;
