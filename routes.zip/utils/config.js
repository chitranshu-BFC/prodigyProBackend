const CONFIG = {};
CONFIG.DOMAIN_NAME = "";
CONFIG.API_URL = "";
CONFIG.SCHEMAS = {
  TEACHERS: "Teachers",
  TEACHERSALIAS: "teachers",
  PARENTS: "Parents",
  STUDENTS: "Students",
  PRINCIPAL: "Principal",
  ORGANIZATION: "organizationDB",
  USER: 'User',
  EXAM: 'Exam',
  EVENTS: 'Events',
  ISSUE: 'Issue',
  ATTENDANCE: 'Attendance',
  SUBJECTS: 'Subjects',
  SCHEDULE: 'Schedule',
  FEE_STRUCTURE: 'feeStructure',
  LEAVE: 'Leave'
};


CONFIG.ROUTES = {
  AUTH: "/auth",
  USER: "/user",
  BASE_ROUTE: "/api",
  LOGIN_WITH_EMAIL: "/login-with-email",
  REGISTER_WITH_EMAIL: "/register-with-email",
  SIPROUTE: "/sip",
  ELSSROUTE: "/elss",
  EMIROUTE: "/emi",
  ADD_PRINCIPAL: "/add-principal",
  FIND_PRINCIPAL: "/find-principal",
  TEACHER: "/teacher",
  STUDENT: "/student",
  PARENT: "/parent",
  REGISTER_STUDENT: "/register-student",
  FIND_STUDENTS: "/find-student",
  ADD_TEACHER: "/add-teacher",
  FIND_TEACHER: "/find-teacher",
  SCHEDULE_EXAM: "/schedule-exam",
  GET_EXAMS: "/get-exams",
  REGISTER_PARENT: "/register-parent",
  ALL_EXAMS: "/all-exams",
  SCHOOL: "/school",
  ADD_SCHOOL: "/add-school",
  GET_SCHOOLS: "/get-schools",
  GET_EVENTS: "/get-events",
  ADD_EVENTS: "/add-events",
  GET_CHILDS: "/get-child",
  RAISE_ISSUES: "/raise-issue",
  GET_ISSUES: "/get-issues",
  USER_LOGIN: "/user-login",
  USER: "/user",
  FILES: "/files",
  UPLOAD_FILES: "/upload-files",
  LOGIN: "/login",
  RESET_PASSWORD: "/reset-password",
  MARK_ATTENDANCE: "/mark-attendance",
  GET_ATTENDANCE: "/get-attendance",
  STUDENT_ATTENDANCE: "/student-attendance",
  ADD_SUBJECTS: "/add-subjects",
  GET_SUBJECTS: "/get-subjects",
  ADD_SCHEDULE: "/add-schedule",
  GET_SCHEDULE: "/get-schedule",
  GET_DASHBOARD: "/get-dashboard",
  ADD_FEE: "/add-fee",
  GET_FEE: "/get-fee",
  GET_SUBJECTS: "/get-Subjects",
  REQUEST_LEAVE: "/request-leave",
  GET_ALL_TEACHERS: "/get-all-teachers"
};


CONFIG.ERROR_CODES = {
  NO_FILES_TO_UPLOAD: 400, // Bad Request
  INTERNAL_SERVER_ERROR: 500,
  FILE_NOT_FOUND: 404,
};
CONFIG.RESPONSE_STATUS = {
  SUCCESS: "S",
  FAIL: "F",
  ERROR: "E",
};

CONFIG.SUCCESS_RESPONSE = 200;

module.exports = CONFIG;
