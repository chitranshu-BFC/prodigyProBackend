const router = require('express').Router();
//routes
const CONFIG = require("../utils/config");
const{
    GET_EXAMS,
    GET_EVENTS,
    LOGIN,
    RAISE_ISSUES,
    GET_DASHBOARD
}=CONFIG.ROUTES

//controllers
const{
    allExams,
    allEvents,
    login,
    raiseIssue,
    Dashboard
}=require('../controller/students');

//token verify middleware
const { verifyToken } = require('../middleware/token');

//Get Exams
router.get(GET_EXAMS, allExams);

//Get Dashboard
router.get(GET_DASHBOARD, Dashboard);

//Get Events
router.get(GET_EVENTS, allEvents);

//Raise Issue
router.post(RAISE_ISSUES, raiseIssue);

//Login
router.post(LOGIN, login);


module.exports = router;