const router = require('express').Router();
const CONFIG = require("../utils/config");
const { use } = require('./calculators');
const {
    AUTH,
    PRINCIPAL,
    TEACHER,
    STUDENT,
    PARENT,
    SCHOOL,
    USER,
    FILES
} = CONFIG.ROUTES;
// routes
// @ /api/auth
router.use(AUTH, require('./auth'));

//Principal routes
// router.use(PRINCIPAL, require('./principal'));

//Teacher's routes
router.use(TEACHER, require('./teacher'));

//Parent's routes
router.use(PARENT, require('./parent'));

//Student's routes
router.use(STUDENT, require('./student'));

//School's route
router.use(SCHOOL, require('./calculators'))

//User's routes
router.use(USER, require('./user'));

//File Upload route
// router.use(FILES, require('./fileupload'));

//Calculators
router.use(require('./calculators'));

//Sample Route
router.get("/sample", async (req, res) => {
    try {
        return res.status(200).send("sample route");
    } catch (error) {
        return res.status(500).send("sample route");
    }
})

module.exports = router;
