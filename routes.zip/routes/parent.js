const router = require('express').Router();
//routes
const CONFIG = require("../utils/config");
const{
    GET_CHILDS,
    GET_ISSUES,
    RAISE_ISSUES
}=CONFIG.ROUTES

//controllers
const {
    allChilds,
    raiseIssue,
    findRaisedIssue
} = require('../controller/parents');


//Get Child
router.get(GET_CHILDS, allChilds);

//Raise Issues
router.post(RAISE_ISSUES, raiseIssue);

//Get Issues
router.get(GET_ISSUES, findRaisedIssue);

module.exports = router;
